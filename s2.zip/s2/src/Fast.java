import java.util.Arrays;
import edu.princeton.cs.algs4.In;
import java.util.Iterator;

public class Fast {
    private final Point[][] lineSegments; // Array to store line segments
    private int numberOfSegments; // Variable to keep track of the number of segments

    public Fast(Point[] points) {
        int n = points.length;
        lineSegments = new Point[n][4]; // Each segment has 4 points
        numberOfSegments = 0;

        // Iterate through each point as the reference point
        for (int i = 0; i < n; i++) {
            Point[] sortedPoints = Arrays.copyOf(points, n);
            Arrays.sort(sortedPoints, points[i].slopeOrder());

            // Iterate through sorted points and find collinear segments
            for (int j = 1; j < n - 2; j++) {
                int k = j + 1;
                while (k < n && points[i].slopeTo(sortedPoints[j]) == points[i].slopeTo(sortedPoints[k])) {
                    k++;
                }

                // Check if 3 or more points have the same slope
                if (k - j >= 3) {
                    Point[] collinearSegment = new Point[k - j + 1];
                    collinearSegment[0] = points[i];
                    for (int l = j; l < k; l++) {
                        collinearSegment[l - j + 1] = sortedPoints[l];
                    }

                    // Sort the segment
                    Arrays.sort(collinearSegment);

                    // Check if this segment has been added before
                    boolean alreadyAdded = false;
                    for (int m = 0; m < numberOfSegments; m++) {
                        if (Arrays.equals(lineSegments[m], collinearSegment)) {
                            alreadyAdded = true;
                            break;
                        }
                    }

                    if (!alreadyAdded) {
                        lineSegments[numberOfSegments++] = collinearSegment;
                    }
                }
                j = k - 1;
            }
        }
    }

    public int numberOfSegments() {
        return numberOfSegments;
    }

    public Iterable<Iterable<Point>> segments() {
        return new SegmentIterable();
    }

    private class SegmentIterable implements Iterable<Iterable<Point>> {
        @Override
        public Iterator<Iterable<Point>> iterator() {
            return new SegmentIterator();
        }
    }

    private class SegmentIterator implements Iterator<Iterable<Point>> {
        private int currentIndex = 0;

        @Override
        public boolean hasNext() {
            return currentIndex < numberOfSegments;
        }

        @Override
        public Iterable<Point> next() {
            return Arrays.asList(lineSegments[currentIndex++]);
        }
    }

    public static void main(String[] args) {
        // Check if the correct number of command-line arguments is provided
        if (args.length != 1) {
            System.out.println("Usage: java Fast <input-file>");
            return;
        }

        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];

        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        Fast fast = new Fast(points);

        // Print the segments
        for (Iterable<Point> segment : fast.segments()) {
            Iterator<Point> iterator = segment.iterator();
            while (iterator.hasNext()) {
                Point point = iterator.next();
                System.out.print("(" + point.x + ", " + point.y + ")");
                if (iterator.hasNext()) {
                    System.out.print(" -> ");
                }
            }
            System.out.println();
        }

    }
}